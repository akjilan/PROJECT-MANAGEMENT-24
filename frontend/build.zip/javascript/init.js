// import 'materialize-css/dist/css/materialize.min.css'
//
// document.addEventListener('DOMContentLoaded', function() {
//     let elems1 = document.querySelectorAll('.sidenav');
//     M.Sidenav.init(elems1);
//
//     let elems2 = document.querySelectorAll('.modal');
//     M.Modal.init(elems2);
// });
